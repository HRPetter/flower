var waveOne = 45; // number of frames for complete oscillation in x direction
var waveTwo = 90; // number of frames for complete oscillation in y direction (2x waveOne creates infinity pattern)
var pointCount = 0; // record number of ellipses
var angle;
var amplitude = 200; // controls spacing between ellipses

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100);
  frameRate(20);
  
}

function draw() {
  
  //stops draw at 1000 ellipses
  if(pointCount > 1000){
    noLoop();
  }
  
  background("black");
  
  // pulsating stroke colour
  stroke(abs(cos(radians(frameCount)) * 360), 100, 50);
  // centre drawing
  translate(width/2, height/2);
  
  beginShape(); 
    for(var i = 0; i < pointCount; i++){
      //calculating coordinates for vertical infinity loop
      angle = i / waveOne * TWO_PI;
      var x = sin (angle) * amplitude;
      angle = i / waveTwo * TWO_PI;
      var y = sin (angle) * amplitude;

      //calculating coordinates for horizonal infinity loop
      // -ve sign rotates infinity loop shape
      angle = i / (-1 * waveTwo) * TWO_PI;
      var j = sin (angle) * amplitude;
      angle = i / (-1 * waveOne) * TWO_PI;
      var k = sin (angle) * amplitude;  

      //adjusts colour as animation progresss
      fill(abs(cos(radians(frameCount)) * 360), 60, 50);

      // draw elipse in horizontal and vertical infinity loop
      ellipse(x,y, 15, 15);
      ellipse(j,k, 15, 15);

      // Add smaller elispe within larger ellipse.
      // Ellipse in horizontal infinity loop is filled blue
      // Ellipse in vertical infinity loop uses pulsating fill
      fill("blue");  
      ellipse(j,k, 10, 10);
      fill(abs(sin(radians(frameCount)) * 360), 60, 50); 
      ellipse(x,y, 10, 10);
  }
  endShape(); 
  pointCount++; // Increase number of ellipses to draw by 1

}